import { Scene } from "./src/core/Scene.js";
import { Renderer2D } from "./src/core/Renderer2D.js";
//import { CameraTransform } from "../libs/transform2d/CameraTransform.js"
import { Camera2D } from "./src/core/Camera2D.js";
import { Path } from "./src/shapes/Path.js";
import { PathShape } from "./src/shapes/PathShape.js";
import { Point } from "./src/shapes/Point.js";
import { Line } from "./src/shapes/Line.js";
import { Rect } from "./src/shapes/Rect.js";
import { Ellipse } from "./src/shapes/Ellipse.js";
import { LineShape } from "./src/shapes/LineShape.js";
import { GestureTool } from "./src/input/Gestures.js";
import { InteractionManager } from "./src/input/InteractionManager.js";

const canvas = document.getElementById("c")
const ctx = canvas.getContext("2d")
//const camera = new CameraTransform(canvas)
const camera = new Camera2D(canvas)
const scene = new Scene();



const renderer = new Renderer2D(canvas, camera, scene);
const info = document.getElementById("info")

const gestures = new GestureTool(canvas)
const interaction = new InteractionManager({
  gestures,
  camera,
  scene
});
gestures.on("move", (data) => {
  console.log("moved geesture")

  const p = data.pointer

  info.innerText = "--------"
  const world = camera.screenToWorld(p.x, p.y)
  const hit = scene.hitTest(world.x, world.y)
  if (hit) {

    info.innerText = hit.name
  }

draw()
})

gestures.on("pinch", (data) => {
   

draw()
})




// --------------------
// Scene
// --------------------

function resize() {
  const dpr = window.devicePixelRatio || 1
  canvas.width = innerWidth * dpr
  canvas.height = innerHeight * dpr
  canvas.style.width = innerWidth + "px"
  canvas.style.height = innerHeight + "px"
  draw()
}

addEventListener("resize", resize)





let camX = 0, camY = 0, zoom = 1

function hitTest(x, y) {


  return null
}

// --------------------
// Gesture
// --------------------

// --------------------
// Render
// --------------------
function draw() {
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.clearRect(0, 0, canvas.width, canvas.height)



  const t = camera.updateMatrix()
  camera.applyToContext(ctx)


  scene.draw(ctx)
  //requestAnimationFrame(draw)
}
createShapes()
resize()
draw()



///////////////////////



function createShapes() {
  const rect = new Rect();
  rect.setPosition(50, 50);
  rect.width = 120;
  rect.height = 80;
  scene.add(rect);

  const ellipse = new Ellipse();
  ellipse.setPosition(350, 120);
  ellipse.radiusX = 60;
  ellipse.radiusY = 40;
  scene.add(ellipse);

  const ls = new LineShape("MyLine");
  ls.stroke.color = "#ff0000";
  ls.stroke.width = 13;
  ls.fill.enabled = false;

  // Add some points dynamically
  ls.addPoints(0, 0, 100, -100, 100, 100, 100, -200);

  // Optional: close the shape to test fill later
  // line.closed = true;

  ls.updateGeometry();

  const line = new Line(0, 0, 300, 10);
  line.stroke.color = "#ff0000";
  line.stroke.width = 3;
  line.fill.enabled = false;
  scene.add(ls, line);

  const lineShape = new LineShape();
  lineShape.stroke.color = "#ff0000";
  lineShape.stroke.width = 3;
  lineShape.fill.enabled = true;
  lineShape.addPoint(0, 0);
  lineShape.addPoint(50, -50);
  lineShape.addPoint(50, 0);
  lineShape.closed = !true;

  lineShape.strokeWidth = 3;
  scene.add(lineShape);
  lineShape.setPosition(-100, -100); // place on canvas
  lineShape.updateGeometry();

  /* -----------------------
     FILLED PATH
  ------------------------ */
  const filledPath = new Path();
  filledPath.moveTo(0, 0);
  filledPath.lineTo(120, 0);
  filledPath.lineTo(100, 80);
  filledPath.lineTo(20, 80);
  // filledPath.closePath();

  const filledShape = new PathShape("FilledPath", filledPath);
  filledShape.setPosition(0, 0);
  filledShape.fill = !true;
  filledShape.stroke = true;
  filledShape.path.lineTo(-40, 100)
  scene.add(filledShape);
  filledShape.setRotation(0.5)

  /* -----------------------
     STROKE ONLY PATH
  ------------------------ */
  const strokePath = new Path();
  strokePath.moveTo(0, 0);
  strokePath.cubicTo(60, -80, 140, 80, 200, 0).moveTo(-500, 0).lineTo(500, 0).moveTo(0, -500).lineTo(0, 500)

  const strokeShape = new PathShape("StrokePath", strokePath);
  strokeShape.setPosition(200, 200);
  strokeShape.fill = false;
  strokeShape.stroke = true;
  strokeShape.strokeWidth = 6;
  scene.add(strokeShape);


}

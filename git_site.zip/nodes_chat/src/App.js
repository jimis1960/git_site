// src/core/App.js
import { Scene } from "./core/Scene.js";
import { Camera2D } from "./core/Camera2D.js";
import { Renderer2D } from "./core/Renderer2D.js";
import { GestureTool } from "./input/Gestures.js";

export class App {
    constructor(canvas) {

        this.canvas = canvas;


        // ----------------------
        // Core objects
        // ----------------------
        this.scene = new Scene();
        this.camera = new Camera2D(canvas);

        this.renderer = new Renderer2D(canvas, this.camera, this.scene);


        // ----------------------
        // Gesture / input
        // ----------------------
        this.gesture = new GestureTool(canvas, (x, y) => this.hitTest(x, y));

        this.selectedShape = null;
        this.offset = { x: 0, y: 0 };

        this._bindGestures();
        this.canvas.addEventListener("mousemove", (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            // Use your existing hitTest helper
            const hovered = this.hitTest(x, y);

            this.scene.children.forEach(s => s.hovered = false);
            if (hovered) {
                hovered.hovered = true;
                // You could trigger a callback here for the UI
            }
        });

        this._loop();
    }

    // ----------------------
    // Hit-test helper
    // ----------------------
    hitTest(x, y) {
        // return first shape under pointer
        const w = this.camera.screenToWorld(x, y);
        for (let i = this.scene.children.length - 1; i >= 0; i--) {
            const s = this.scene.children[i];
            if (s.hitTest(w.x, w.y)) return s;
        }
        return null;
    }

    // ----------------------
    // Gesture events
    // ----------------------
    _bindGestures() {
        this.gesture.on("down", ({ pointer, hit }) => {
            if (hit) {
                this.selectedShape = hit;
                this.offset.x = pointer.x - hit.position.x;
                this.offset.y = pointer.y - hit.position.y;
            }
        });

        this.gesture.on("drag", ({ dx, dy, hit }) => {
            if (this.selectedShape) {
                // update shape position
                this.selectedShape.setPosition(
                    this.gesture.sessions.get(hit?.id)?.curr.x - this.offset.x || this.selectedShape.position.x + dx,
                    this.gesture.sessions.get(hit?.id)?.curr.y - this.offset.y || this.selectedShape.position.y + dy
                );
            }
        });

        this.gesture.on("up", ({ id }) => {
            this.selectedShape = null;
        });
    }

    // ----------------------
    // Main loop
    // ----------------------
    _loop() {
        this.renderer.render();
        alert("loop ")
        requestAnimationFrame(() => this._loop());
    }
}

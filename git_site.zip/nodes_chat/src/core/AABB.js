export class AABB {
  constructor(x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity) {
    this.set(x0, y0, x1, y1);
  }

  set(x0, y0, x1, y1) {
    this.x0 = x0;
    this.y0 = y0;
    this.x1 = x1;
    this.y1 = y1;
    return this;
  }

  copy(other) {
    this.x0 = other.x0;
    this.y0 = other.y0;
    this.x1 = other.x1;
    this.y1 = other.y1;
    return this;
  }

  expandByPoint(p) {
    if (p.x < this.x0) this.x0 = p.x;
    if (p.y < this.y0) this.y0 = p.y;
    if (p.x > this.x1) this.x1 = p.x;
    if (p.y > this.y1) this.y1 = p.y;
    return this;
  }

  expandByAABB(aabb) {
    this.expandByPoint({ x: aabb.x0, y: aabb.y0 });
    this.expandByPoint({ x: aabb.x1, y: aabb.y1 });
    return this;
  }

  containsPoint(p) {
    return p.x >= this.x0 && p.x <= this.x1 && p.y >= this.y0 && p.y <= this.y1;
  }

  intersectsAABB(aabb) {
    return !(aabb.x1 < this.x0 || aabb.x0 > this.x1 || aabb.y1 < this.y0 || aabb.y0 > this.y1);
  }

  reset() {
    this.x0 = Infinity;
    this.y0 = Infinity;
    this.x1 = -Infinity;
    this.y1 = -Infinity;
    return this;
  }
}

import { Scene } from "./Scene.js";
import { GestureTool } from "../input/Gestures.js";

/**
 * App
 * Orchestrates input → scene
 */
export class App {
  constructor(canvas) {
    this.canvas = canvas;

    // ---- core systems ----
    this.scene = new Scene();
    this.gestures = new GestureTool(
      canvas,
      (x, y) => this.scene.hitTest(x, y)
    );

    // ---- bind input ----
    this._bindGestures();
  }

  // ----------------------------------------
  // Gesture → Scene routing
  // ----------------------------------------
  _bindGestures() {
    this.gestures.on("down", e => {
      this.scene.pointerDown({
        x: e.pointer.x,
        y: e.pointer.y,
        pointerId: e.pointer.id,
        hit: e.hit
      });
    });

    this.gestures.on("drag", e => {
      this.scene.pointerDrag({
        dx: e.dx,
        dy: e.dy,
        pointerId: e.hit ? e.hit.id : null
      });
    });

    this.gestures.on("up", e => {
      this.scene.pointerUp({
        pointerId: e.id
      });
    });
  }

  // ----------------------------------------
  // Utilities
  // ----------------------------------------
  get root() {
    return this.scene;
  }
}

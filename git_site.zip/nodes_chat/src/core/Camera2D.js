import { Matrix3 } from "./Matrix3.js";

export class Camera2D {
  constructor(canvas) {
    this.canvas = canvas;

    this.position = { x: 0, y: 0 }; // world point at screen center
    this.zoom = 1;
    this.rotation = 0; // future-proof

    this.worldMatrix = new Matrix3();
    this._inverseMatrix = new Matrix3();

    this.updateMatrix();
  }

  // ---------------------------
  updateMatrix() {
    const cx = this.canvas.width / 2;
    const cy = this.canvas.height / 2;

    this.worldMatrix.identity()
      .multiply(new Matrix3().makeTranslation(cx, cy))
      .multiply(new Matrix3().makeScale(this.zoom, this.zoom))
      // .multiply(new Matrix3().makeRotation(this.rotation)) // optional later
      .multiply(new Matrix3().makeTranslation(
        -this.position.x,
        -this.position.y
      ));

    this._inverseMatrix.copy(this.worldMatrix).invert();
  }

  // ---------------------------
  pan(dx, dy) {
    this.position.x -= dx / this.zoom;
    this.position.y -= dy / this.zoom;
    this.updateMatrix();
  }

  zoomAt(screenX, screenY, factor) {
    const before = this.screenToWorld(screenX, screenY);

    this.zoom *= factor;
    this.updateMatrix();

    const after = this.screenToWorld(screenX, screenY);

    this.position.x += before.x - after.x;
    this.position.y += before.y - after.y;

    this.updateMatrix();
  }

  // ---------------------------
  screenToWorld(sx, sy) {
    return this._inverseMatrix.applyToPoint(sx, sy);
  }

  worldToScreen(wx, wy) {
    return this.worldMatrix.applyToPoint(wx, wy);
  }

  applyToContext (ctx){
    this.worldMatrix.applyCanvasTransform(ctx)
  }
}

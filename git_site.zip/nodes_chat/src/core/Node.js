/**
 * Node.js
 * Enhanced Node class for editor/scene graphs 8/1
 */

export class Node {
    // ------------------------
    // Static registry + selection
    // ------------------------
    static registry = new Map();


    /** Currently selected node(s) */
    static hit=null; // track hit if any
    static currentNode = null;           // single selection
    static selection = new Set();        // multi-selection
    // shared empty array for all collapsed nodes
    static _EMPTY_CHILDREN = [];
    static register(cls) {
        if (typeof cls !== 'function') throw new TypeError('Only constructor functions can be registered');
        Node.registry.set(cls.name, cls);
    }

    // ------------------------
    // Constructor
    // ------------------------
    constructor(name = "Node") {

        this.__class = this.constructor.name;
        this.id = Math.random().toString();// crypto.randomUUID();
        this.name = name;
        this.children = [];
        this.parent = null;

        // Event dispatcher
        this.listeners = new Map();

        // Interaction/UI state (not serialized)
        this.selected = false;
        this.isDragging = false;
        this.dropActive = false;

        this.expanded = true; // default: children visible

        // Persistent capabilities
        this.dropTypes = [];

        // Notification suppression
        this._suppressNotifications = false;
    }
    // ------------------------
    // Expand / Collapse support
    // ------------------------



    get visibleChildren() {
        return this.expanded ? this.children : Node._EMPTY_CHILDREN;
    }

    // Method to toggle expand/collapse
    toggleExpand() {
        this.expanded = !this.expanded;
        this.notify('expand-toggle', { node: this, expanded: this.expanded });
    }

    // Optional convenience methods
    expand() {
        if (!this.expanded) {
            this.expanded = true;
            this.notify('expand-toggle', { node: this, expanded: true });
        }
    }

    collapse() {
        if (this.expanded) {
            this.expanded = false;
            this.notify('expand-toggle', { node: this, expanded: false });
        }
    }





    destroy() {
        // 1. Recursive cleanup (children FIRST, parent LAST)
        this.traverse(node => {
            // notify listeners before teardown
            node.emit?.('destroying', { node });

            // remove from selection system
            node.selected = false;
            Node.selection.delete(node);
            if (Node.currentNode === node) Node.currentNode = null;

            // subclass cleanup hook
            if (typeof node.onDestroy === 'function') {
                node.onDestroy();
            }

            // prevent further notifications
            node._suppressNotifications = true;

            // clear event listeners (avoid leaks)
            node.listeners.clear();
        });

        // 2. Detach from parent AFTER cleanup
        if (this.parent) {
            this.remove();
        }

        // 3. Break hierarchy links for GC
        const deletedChildren = this.children;
        this.children = [];
        this.parent = null;

        return deletedChildren;
    }





    // ------------------------
    // Add / Remove / Notify
    // ------------------------
    add(...children) {

        const flatChildren = children.flat(Infinity);

        if (flatChildren.length === 0) return [];

        const wasSuppressed = this._suppressNotifications;
        this._suppressNotifications = true;

        try {
            for (const child of flatChildren) {
                if (!Node.isNode(child)) {
                    throw new TypeError(
                        `Expected Node instance, got ${child?.constructor?.name || typeof child}`
                    );
                }
                if (this.children.includes(child)) throw new Error("Cannot add duplicate node reference");
                if (child.isAncestorOf(this)) throw new Error("Cannot add ancestor as child");

                child.parent = this;
                this.children.push(child);
            }
        } finally {
            this._suppressNotifications = wasSuppressed;
        }

        if (!wasSuppressed) {
            this.notify('add', {
                added: flatChildren.length === 1 ? flatChildren[0] : flatChildren,
                count: flatChildren.length
            });
        }

        return flatChildren.length === 1 ? flatChildren[0] : flatChildren;
    }

    addBulk(children) {
        return this.add(...children);
    }

    remove() {
        if (!this.parent) return false;

        const parent = this.parent;
        const index = parent.children.indexOf(this);
        if (index === -1) return false;

        parent.children.splice(index, 1);
        this.parent = null;

        parent.notify('remove', { removed: this, index });
        return true;
    }

    // ------------------------
    // Copy / Clone
    // ------------------------
    copy(customizer = null) {
        // serialize
        const data = this.toJSON();

        // reconstruct through registry
        const copyRoot = Node.fromJSON(data);

        // restore runtime state
        copyRoot.afterLoad();

        // assign NEW ids to entire subtree
        copyRoot.traverse(node => {
            node.id = crypto.randomUUID();
        });

        // allow caller customization (optional)
        if (typeof customizer === 'function') {
            customizer(copyRoot);
        }

        return copyRoot;
    }

    clone(deep = true) {
        // create instance without calling constructor
        const clone = Object.create(this.constructor.prototype);

        // copy primitive / persistent fields
        clone.__class = this.__class;
        clone.id = crypto.randomUUID();
        clone.name = this.name;

        // hierarchy
        clone.parent = null;
        clone.children = [];

        // runtime / editor state (reset)
        clone.selected = false;
        clone.isDragging = false;
        clone.dropActive = false;
        clone.expanded = this.expanded;

        // notifications
        clone._suppressNotifications = false;
        clone.listeners = new Map();

        // capabilities (deep copy!)
        clone.dropTypes = Array.isArray(this.dropTypes)
            ? [...this.dropTypes]
            : [];

        // ---- deep clone children ----
        if (deep) {
            for (const child of this.children) {
                const childClone = child.clone(true);
                childClone.parent = clone;
                clone.children.push(childClone);
            }
        }

        return clone;
    }


    // ------------------------
    // Notify
    // ------------------------
    notify(type = 'update', extraData = {}) {
        if (this._suppressNotifications) return;

        const payload = {
            node: this,
            type,
            ...extraData
        };

        // semantic event (preferred)
        this.emit?.(type, payload);

        // generic catch-all event
        this.emit?.('change', payload);
    }



    // ------------------------
    // Selection helpers
    // ------------------------
    select(additive = false) {
        if (!additive) {
            Node.clearSelection();
        }

        this.selected = true;
        Node.selection.add(this);
        Node.currentNode = this;
        this.emit?.('selected', { node: this, additive });
    }

    deselect() {
        this.selected = false;
        Node.selection.delete(this);
        if (Node.currentNode === this) Node.currentNode = null;
        this.emit?.('deselected', { node: this });
    }

    static clearSelection() {
        for (const n of Node.selection) n.selected = false;
        Node.selection.clear();
        Node.currentNode = null;
    }

    static getSelected() {
        return Array.from(Node.selection);
    }

    // ------------------------
    // Traversal
    // ------------------------
    traverse(callback) {
        callback(this);
        this.children.forEach(c => c.traverse(callback));
    }

    traverseWithDepth(callback, depth = 0) {
        callback(this, depth);
        this.children.forEach(c => c.traverseWithDepth(callback, depth + 1));
    }

    filter(predicate) {
        let results = [];
        if (predicate(this)) results.push(this);
        this.children.forEach(c => results = results.concat(c.filter(predicate)));
        return results;
    }

    find(predicate) {
        if (predicate(this)) return this;
        for (const c of this.children) {
            const found = c.find(predicate);
            if (found) return found;
        }
        return null;
    }

    findByPath(pathArray) {
        let current = this;
        for (const segment of pathArray) {
            const found = current.children.find(c => c.name === segment || c.id === segment);
            if (!found) return null;
            current = found;
        }
        return current;
    }

    get nodePath() {
        const path = [];
        let n = this;
        while (n) {
            path.unshift(n);
            n = n.parent;
        }
        return path;
    }

    // ------------------------
    // Move / Reorder
    // ------------------------
    moveUp() {
        if (!this.parent) return;
        const siblings = this.parent.children;
        const i = siblings.indexOf(this);
        if (i <= 0) return;
        [siblings[i - 1], siblings[i]] = [siblings[i], siblings[i - 1]];
        this.emit?.("orderChanged", { type: "moveUp" });
    }

    moveDown() {
        if (!this.parent) return;
        const siblings = this.parent.children;
        const i = siblings.indexOf(this);
        if (i === -1 || i >= siblings.length - 1) return;
        [siblings[i], siblings[i + 1]] = [siblings[i + 1], siblings[i]];
        this.emit?.("orderChanged", { type: "moveDown" });
    }

    moveTop() {
        if (!this.parent) return;
        const siblings = this.parent.children;
        const i = siblings.indexOf(this);
        if (i === -1 || i === siblings.length - 1) return;
        siblings.splice(i, 1);
        siblings.push(this);
        this.emit?.("orderChanged", { type: "moveTop" });
    }

    moveBottom() {
        if (!this.parent) return;
        const siblings = this.parent.children;
        const i = siblings.indexOf(this);
        if (i <= 0) return;
        siblings.splice(i, 1);
        siblings.unshift(this);
        this.emit?.("orderChanged", { type: "moveBottom" });
    }

    reparent(newParent) {
        if (!newParent) return;
        if (newParent === this.parent) return;
        if (newParent === this) return;

        // prevent cycles
        let p = newParent;
        while (p) {
            if (p === this) return;
            p = p.parent;
        }

        // remove from old parent using official API
        if (this.parent) {
            this.remove();
        }

        // add to new parent using official API
        newParent.add(this);

        // notify explicitly (semantic event)
        this.emit?.("parentChanged", {
            node: this,
            newParent
        });
    }


    // ------------------------
    // Event system
    // ------------------------
    on(event, callback, { once = false } = {}) {
        if (!this.listeners.has(event)) this.listeners.set(event, new Set());
        const wrapper = once ? (data) => { callback(data); this.off(event, wrapper); } : callback;
        wrapper._originalCallback = callback;
        this.listeners.get(event).add(wrapper);
        return () => this.off(event, wrapper);
    }

    off(event, callback) {
        if (!this.listeners.has(event)) return;
        const cbs = this.listeners.get(event);
        if (callback) {
            for (const cb of cbs) if (cb === callback || cb._originalCallback === callback) cbs.delete(cb);
        } else cbs.clear();
        if (cbs.size === 0) this.listeners.delete(event);
    }

    emit(event, data = {}) {
        if (!this.listeners.has(event)) return;
        const callbacks = new Set(this.listeners.get(event));
        for (const cb of callbacks) {
            try { cb(data); } catch (e) { console.error(e); }
        }
    }

    // ------------------------
    // Hierarchy helpers
    // ------------------------
    get root() {
        let n = this;
        while (n.parent) n = n.parent;
        return n;
    }

    get depth() {
        let d = 0;
        let n = this.parent;
        while (n) { d++; n = n.parent; }
        return d;
    }

    get index() { return this.parent?.children.indexOf(this) ?? -1; }
    get siblings() { return this.parent ? this.parent.children.filter(c => c !== this) : []; }

    isRoot() { return this.parent === null; }
    isLeaf() { return this.children.length === 0; }
    isAncestorOf(node) { let c = node; while (c) { if (c === this) return true; c = c.parent; } return false; }
    isDescendantOf(node) { return node.isAncestorOf(this); }



    // ------------------------
    // Node type helpers
    // ------------------------
    static isNode(obj) {
        return obj instanceof Node;
    }


    static create(type = 'Node', ...args) {
        const Cls = Node.registry.get(type) || Node;
        return new Cls(...args);
    }

    /////////////////  io //////////////////// 
    static saveToStorage(node, key = 'node-tree') {
        if (!node || typeof node.toJSON !== 'function') throw new TypeError('Invalid Node');
        const json = JSON.stringify(node.toJSON(), null, 2);
        localStorage.setItem(key, json);
    }

    static loadFromStorage(key = 'node-tree') {
        const json = localStorage.getItem(key);
        if (!json) return null;
        const data = JSON.parse(json);
        const node = Node.fromJSON(data);
        node.afterLoad();
        return node;
    }

    // ------------------------
    // Export / Import to File
    // ------------------------
    static exportToFile(node, { filename = 'node-export.json' } = {}) {
        const json = JSON.stringify(node.toJSON(), null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();

        URL.revokeObjectURL(url);
    }

    static async importFromFile(file) {
        if (!file) return null;
        const text = await file.text();
        const data = JSON.parse(text);
        const node = Node.fromJSON(data);
        node.afterLoad();
        return node;
    }

    /////// end io //////////////////////////


    // ------------------------
    // Conversion utilities
    // ------------------------
    // Flattened list of nodes
    static convert(node, mode = 'flat') {
        if (mode === 'flat') {
            const list = [];
            node.traverse(n => list.push(n));
            return list;
        } else if (mode === 'indented') {
            let str = '';
            node.traverseWithDepth((n, depth) => {
                str += '  '.repeat(depth) + n.name + '\n';
            });
            return str;
        }
        return null;
    }

    // ------------------------
    // Backups
    // ------------------------
    static backup(node, name = null) {
        const key = `backup-${name || Date.now()}`;
        Node.saveToStorage(node, key);
        return key;
    }

    static listBackups() {
        return Object.keys(localStorage).filter(k => k.startsWith('backup-'));
    }

    // ------------------------
    // Serialization / afterLoad
    // ------------------------
    toJSON() {
        return {
            __class: this.__class,
            id: this.id,
            name: this.name,
            dropTypes: [...(this.dropTypes || [])],
            children: this.children.map(c => c.toJSON())
        };
    }

    afterLoad() {
        // reset parent links
        this.children.forEach(c => { c.parent = this; c.afterLoad(); });

        // normalize dropTypes
        this.dropTypes = Array.isArray(this.dropTypes) ? this.dropTypes.filter(t => typeof t === 'string') : [];
        this.dropTypes = [...this.dropTypes];

        // optional: reset runtime flags
        this.isDragging = false;
        this.dropActive = false;
        this.selected = false;

        // optional: reset listeners (for runtime)
        this.listeners = new Map();
    }



    // ------------------------
    // JSON reconstruction
    // ------------------------
    static fromJSON(data) {
        if (Array.isArray(data)) return data.map(d => Node.fromJSON(d));

        if (data && typeof data === 'object') {
            const clsName = data.__class || 'Node';
            const Cls = Node.registry.get(clsName) || Node;
            const node = Object.create(Cls.prototype);

            // assign persistent properties
            const { children, dropTypes, ...props } = data;
            Object.assign(node, props);
            node.dropTypes = Array.isArray(dropTypes) ? [...dropTypes] : [];

            // reconstruct children recursively
            node.children = Array.isArray(children)
                ? children.map(c => Node.fromJSON(c))
                : [];

            // --- INIT RUNTIME / editor state ---
            node.listeners = new Map();
            node._suppressNotifications = false;
            node.selected = false;
            node.isDragging = false;
            node.dropActive = false;
            node.expanded = true;

            return node;
        }

        return data;
    }







}

// register base class once 
Node.register(Node);

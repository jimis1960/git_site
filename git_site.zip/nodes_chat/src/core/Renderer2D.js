/**
 * Renderer2D
 * Dumb canvas renderer
 */
export class Renderer2D {
  constructor(canvas, camera, scene) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.camera = camera;
    this.scene = scene;

    this.dpr = window.devicePixelRatio || 1;
  }

  // --------------------------------------------------
  // Canvas resize (call on load & resize)
  // --------------------------------------------------
  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = this.dpr;

    const w = Math.round(rect.width * dpr);
    const h = Math.round(rect.height * dpr);

    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }

  // --------------------------------------------------
  // Frame render
  // --------------------------------------------------
  render() {
    this.resize();

    const ctx = this.ctx;
    const canvas = this.canvas;

    // reset transform
    ctx.fillStyle="#aabbcc"
    ctx.setTransform(1, 0, 0, 1, 0, 0);

    // clear
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // apply camera transform
    this.camera.applyToContext(ctx);

    // draw scene
    if (this.scene && this.scene.draw) {
      this.scene.draw(ctx);
    }
  }
}

// core/Scene.js
import { Shape } from "../shapes/Shape.js";

export class Scene extends Shape {
  constructor() {
    super("Scene");
    this.__class = "Scene";

    // Scene is never selectable / draggable itself
    this.selectable = false;
    this.hitEnabled = false;
  }

   // draw(ctx) and drawSelf form Shape



  hitTestLocal(x, y,ctx) {
    // Scene itself is not hittable
    return false;
  }

  /**
   * Topmost hit (reverse order)
   */
  hitTest(x, y) {
    for (let i = this.children.length - 1; i >= 0; i--) {
      const c = this.children[i];
      if (c.hitTest && c.hitTest(x, y)) {
        return c;
      }
    }
    return null;
  }
}

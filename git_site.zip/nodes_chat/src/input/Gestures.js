// =======================================
// GestureTool Pro: Multi-pointer + Inertia
// =======================================

export class InputAdapter {
  constructor(canvas) { this.canvas = canvas }
  eventToCanvas(e) {
    const rect = this.canvas.getBoundingClientRect()
    const dpr = window.devicePixelRatio || 1
    return {
      x: (e.clientX - rect.left) * dpr,
      y: (e.clientY - rect.top) * dpr,
      dpr,
      pointerId: e.pointerId,
      pointerType: e.pointerType,
      pressure: e.pressure ?? 0,
      time: performance.now()
    }
  }
}


// ======================================
// GestureTool
// ======================================

// src/Gesture.js// ======================================
// GestureTool - Safe Multi-Pointer Logic
// ======================================

export class GestureTool {
  constructor(canvas) {
    this.canvas = canvas;
     
    this.sessions = new Map();
    this.listeners = new Map();

    this._bind();
  }

  on(type, fn) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(fn);
  }

  emit(type, data) {
    const handlers = this.listeners.get(type);
    if (handlers) handlers.forEach(fn => fn(data));
  }

  _bind() {
    // Prevents default touch behaviors like scrolling/zooming the browser
    this.canvas.style.touchAction = "none";

    this.canvas.addEventListener("pointerdown", e => this._down(e));
    this.canvas.addEventListener("pointermove", e => this._move(e));
    this.canvas.addEventListener("pointerup", e => this._up(e));
    this.canvas.addEventListener("pointercancel", e => this._up(e));

    this.canvas.addEventListener("wheel", e => this._wheel(e), { passive: false })
  }

  _eventToCanvas(e) {
    const r = this.canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    return {
      x: (e.clientX - r.left) * dpr,
      y: (e.clientY - r.top) * dpr,
      id: e.pointerId
    };
  }

  _wheel(e) {
    e.preventDefault()

    // Ignore wheel while multi-touch is active
    if (this.sessions.size > 0) return

    const r = this.canvas.getBoundingClientRect()
    const dpr = window.devicePixelRatio || 1

    const x = (e.clientX - r.left) * dpr
    const y = (e.clientY - r.top) * dpr

    // Trackpad-friendly exponential zoom
    const sensitivity = 0.0015
    const scale = Math.exp(-e.deltaY * sensitivity)

    this.emit("pinch", {
      scale,
      focalX: x,
      focalY: y,
      dx: 0,
      dy: 0,
      source: "wheel"
    })
  }

  _down(e) {
    // CAPTURE: Ensures pointer events continue even if finger leaves element
    this.canvas.setPointerCapture(e.pointerId);

    const p = this._eventToCanvas(e);
     

    this.sessions.set(p.id, {
      id: p.id,
      prev: { x: p.x, y: p.y },
      curr: { x: p.x, y: p.y }
    });

    this.emit("down", { pointer: p });
  }

  _move(e) {
    const p = this._eventToCanvas(e);
    this.emit("move", { pointer: p }); /// just moved need coords
    const s = this.sessions.get(e.pointerId);
    if (!s) return;

    
    // Update coordinates
    s.prev.x = s.curr.x;
    s.prev.y = s.curr.y;
    s.curr.x = p.x;
    s.curr.y = p.y;

    const pointers = [...this.sessions.values()];

    // SINGLE FINGER: DRAG
    if (pointers.length === 1) {
      this.emit("drag", {
        dx: s.curr.x - s.prev.x,
        dy: s.curr.y - s.prev.y
      });

    }

    // TWO FINGERS: PINCH & PAN
    if (pointers.length === 2) {
      const [a, b] = pointers;

      // Distance calculation
      const dx = b.curr.x - a.curr.x;
      const dy = b.curr.y - a.curr.y;
      const currDist = Math.sqrt(dx * dx + dy * dy);

      const pdx = b.prev.x - a.prev.x;
      const pdy = b.prev.y - a.prev.y;
      const prevDist = Math.sqrt(pdx * pdx + pdy * pdy);

      // SAFE SCALE: Prevent Infinity/NaN if distance is zero
      const scale = (prevDist > 0) ? currDist / prevDist : 1;

      // Centroid (Center point between fingers)
      const currCx = (a.curr.x + b.curr.x) * 0.5;
      const currCy = (a.curr.y + b.curr.y) * 0.5;
      const prevCx = (a.prev.x + b.prev.x) * 0.5;
      const prevCy = (a.prev.y + b.prev.y) * 0.5;

      this.emit("pinch", {
        scale,
        focalX: currCx,
        focalY: currCy,
        dx: currCx - prevCx,
        dy: currCy - prevCy
      });
    }
  }

  _up(e) {
    // RELEASE: Clean up session and pointer capture
    if (this.sessions.has(e.pointerId)) {
      this.canvas.releasePointerCapture(e.pointerId);
      this.sessions.delete(e.pointerId);
      this.emit("up", { id: e.pointerId });
    }
  }
}
// src/input/InteractionManager.js

export class InteractionManager {
  constructor({ gestures, camera, scene }) {
    this.gestures = gestures;
    this.camera = camera;
    this.scene = scene;

    this.hovered = null;
    this.active = null;

    this._bind();
  }

  _bind() {
    this.gestures.on("move", e => this._onMove(e));
    this.gestures.on("down", e => this._onDown(e));
    this.gestures.on("drag", e => this._onDrag(e));
    this.gestures.on("up", () => this._onUp());
     this.gestures.on("pinch", e => this._onPinch(e));
     
  }
  _onPinch({ scale, focalX, focalY, dx, dy }) {
    
    

    this.camera.zoomAt( focalX, focalY,scale);

    // optional two-finger pan
    this.camera.x -= dx;
    this.camera.y -= dy;

     
  }
  _screenToWorld(x, y) {
    return this.camera.screenToWorld(x, y);
  }

  _hitTest(x, y) {
    return this.scene.hitTest(x, y);
  }

  _onMove({ pointer }) {
    const w = this._screenToWorld(pointer.x, pointer.y);
    const hit = this._hitTest(w.x, w.y);

    if (hit !== this.hovered) {
      if (this.hovered) this.hovered.onHoverEnd?.();
      if (hit) hit.onHoverStart?.();
      this.hovered = hit;
    }
  }

  _onDown({ pointer }) {
    const w = this._screenToWorld(pointer.x, pointer.y);
    this.active = this._hitTest(w.x, w.y);

    this.active?.onSelect?.();
  }

  _onDrag({ x, y, dx, dy }) {
    const w = this._screenToWorld(x, y);

    if (this.active) {
      this.active.translate(dx/this.camera.zoom, dy/this.camera.zoom);
      return;
    }

    // fallback: pan camera
    this.camera.pan(dx, dy);
  }

  _onUp() {
    this.active?.onRelease?.();
    this.active = null;
  }
}

import { Scene } from "./core/Scene.js";
import { Camera2D } from "./core/Camera2D.js";
import { Renderer2D } from "./core/Renderer2D.js";
import { GestureTool } from "./input/Gestures.js";
import { Poly } from "./shapes/Poly.js";

// --------------------
// Canvas setup
// --------------------
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

function resize() {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = innerWidth * dpr;
  canvas.height = innerHeight * dpr;
}
window.addEventListener("resize", resize);
resize();

// --------------------
// Scene & Camera
// --------------------
const scene = new Scene();
const camera = new Camera2D(canvas);
const renderer = new Renderer2D(ctx, scene, camera);

// --------------------
// Demo Polys
// --------------------
function makePoly(x, y, color) {
  const poly = new Poly();
  poly.points = [
    {x:-40,y:-30}, 
    {x:40,y:-20}, 
    {x:60,y:30}, 
    {x:-30,y:40}
  ];
  poly.closed = true;
  poly.setPosition(x, y);
  poly.fill = { enabled: true, color, alpha: 0.6 };
  poly.stroke = { enabled: true, color:"#fff", width:2 };
  return poly;
}

scene.add(makePoly(200, 200, "#ff5555"));
scene.add(makePoly(400, 250, "#55ff55"));
scene.add(makePoly(300, 400, "#5599ff"));

// --------------------
// Gesture tool
// --------------------
let activeShape = null;

const gestures = new GestureTool(canvas, (x, y) => {
  // convert canvas -> scene coords
  const p = camera.canvasToWorld(x, y);
  return scene.hitTest(p.x, p.y);
});

gestures.on("down", ({ hit }) => {
  activeShape = hit;
  if (activeShape) {
    activeShape.hovered = true;
    scene.bringToFront(activeShape);
  }
});

gestures.on("drag", ({ dx, dy }) => {
  if (!activeShape) return;
  activeShape.translate(dx / camera.zoom, dy / camera.zoom);
});

gestures.on("up", () => {
  if (activeShape) {
    activeShape.hovered = false;
    activeShape = null;
  }
});

// --------------------
// Render loop
// --------------------
function loop() {
  renderer.render();
  requestAnimationFrame(loop);
}
loop();

import { App } from "./core/App.js";
import { Rect } from "./shapes/Rect.js";
import { Ellipse } from "./shapes/Ellipse.js";
import { Path } from "./shapes/Path.js";
import { PathShape } from "./shapes/PathShape.js";

const canvas = document.getElementById("c");
const app = new App(canvas);

// Add some shapes
const r = new Rect();
r.setPosition(100,100); r.width=120; r.height=80;
app.scene.add(r);

const e = new Ellipse();
e.setPosition(350,150); e.radiusX=60; e.radiusY=40;
app.scene.add(e);

const path = new Path();
path.moveTo(0,0); path.lineTo(120,0); path.lineTo(100,80);
const ps = new PathShape("MyPath", path);
ps.setPosition(200,300);
app.scene.add(ps);


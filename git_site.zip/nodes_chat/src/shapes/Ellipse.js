// shapes/Ellipse.js
import { Shape } from "./Shape.js";

export class Ellipse extends Shape {
  constructor(x = 0, y = 0, rx = 50, ry = 25, name = "Ellipse") {
    super(name);
    this.x = x;
    this.y = y;
    this.rx = rx;
    this.ry = ry;
  }

  // -----------------------
  // Compute geometry (AABB)
  // -----------------------
  computeGeometry() {
    this.aabb = {
      x0: this.x - this.rx,
      y0: this.y - this.ry,
      x1: this.x + this.rx,
      y1: this.y + this.ry,
    };
  }

  // -----------------------
  // Draw the ellipse
  // -----------------------
  drawSelf(ctx) {
    ctx.beginPath();
    ctx.ellipse(this.x, this.y, this.rx, this.ry, 0, 0, Math.PI * 2);

    if (this.fill?.enabled) {
      ctx.fillStyle = this.fill.color;
      ctx.globalAlpha = this.fill.alpha ?? 1;
      ctx.fill();
    }

    if (this.stroke?.enabled) {
      ctx.strokeStyle = this.stroke.color;
      ctx.lineWidth = this.stroke.width;
      ctx.globalAlpha = this.stroke.alpha ?? 1;
      ctx.stroke();
    }
  }

  // -----------------------
  // Hit test in local coordinates
  // -----------------------
  hitTestLocal(px, py) {
    // Normalize to ellipse coordinates
    const nx = (px - this.x) / this.rx;
    const ny = (py - this.y) / this.ry;
    const inside = nx * nx + ny * ny <= 1;

    if (inside && this.fill?.enabled) return true;

    if (this.stroke?.enabled) {
      // Approximate stroke hit
      const dist = Math.abs(Math.sqrt(nx * nx + ny * ny) - 1);
      const tolerance = (this.stroke.width ?? 1) / Math.max(this.rx, this.ry);
      return dist <= tolerance;
    }

    return false;
  }

  // -----------------------
  // Serialization
  // -----------------------
  toJSON() {
    return {
      ...super.toJSON(),
      x: this.x,
      y: this.y,
      rx: this.rx,
      ry: this.ry,
    };
  }

  static fromJSON(data) {
    const ellipse = super.fromJSON(data);
    ellipse.x = data.x ?? 0;
    ellipse.y = data.y ?? 0;
    ellipse.rx = data.rx ?? 50;
    ellipse.ry = data.ry ?? 25;
    return ellipse;
  }

  afterLoad() {
    super.afterLoad();
    this.computeGeometry();
  }
}

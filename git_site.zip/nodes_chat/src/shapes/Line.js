// shapes/Line.js
import { Shape } from "./Shape.js";

export class Line extends Shape {
  constructor(x0 = 0, y0 = 0, x1 = 100, y1 = 0, name = "Line") {
    super(name);
    this.p0 = { x: x0, y: y0 };
    this.p1 = { x: x1, y: y1 };
  }

  // -----------------------
  // Compute geometry (AABB)
  // -----------------------
  computeGeometry() {
    const minX = Math.min(this.p0.x, this.p1.x);
    const minY = Math.min(this.p0.y, this.p1.y);
    const maxX = Math.max(this.p0.x, this.p1.x);
    const maxY = Math.max(this.p0.y, this.p1.y);
    this.aabb = { x0: minX, y0: minY, x1: maxX, y1: maxY };
  }

  // -----------------------
  // Draw the line
  // -----------------------
  drawSelf(ctx) {
    ctx.beginPath();
    ctx.moveTo(this.p0.x, this.p0.y);
    ctx.lineTo(this.p1.x, this.p1.y);

    if (this.stroke?.enabled) {
      ctx.strokeStyle = this.stroke.color;
      ctx.lineWidth = this.stroke.width;
      ctx.stroke();
    }
  }

  // -----------------------
  // Hit test (point near line)
  // -----------------------
  hitTestLocal(x, y) {
    return Line.distancePointToLine(x, y, this.p0.x, this.p0.y, this.p1.x, this.p1.y) <= (this.stroke?.width || 2);
  }

  // -----------------------
  // Utility: distance from point to line segment
  // -----------------------
  static distancePointToLine(px, py, x0, y0, x1, y1) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    if (dx === 0 && dy === 0) {
      // degenerate line
      const dx0 = px - x0;
      const dy0 = py - y0;
      return Math.sqrt(dx0 * dx0 + dy0 * dy0);
    }
    const t = ((px - x0) * dx + (py - y0) * dy) / (dx * dx + dy * dy);
    if (t < 0) return Math.hypot(px - x0, py - y0);
    if (t > 1) return Math.hypot(px - x1, py - y1);
    const projX = x0 + t * dx;
    const projY = y0 + t * dy;
    return Math.hypot(px - projX, py - projY);
  }

  // -----------------------
  // Serialization
  // -----------------------
  toJSON() {
    return {
      ...super.toJSON(),
      p0: this.p0,
      p1: this.p1
    };
  }

  static fromJSON(data) {
    const line = super.fromJSON(data);
    line.p0 = data.p0 ?? { x: 0, y: 0 };
    line.p1 = data.p1 ?? { x: 100, y: 0 };
    return line;
  }

  afterLoad() {
    super.afterLoad();
    this.computeGeometry();
  }
}

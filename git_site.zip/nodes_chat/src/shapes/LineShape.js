// shapes/LineShape.js
import { Shape } from "./Shape.js";
import { Path } from "./Path.js"; // Optional if you want Path hit test helper

export class LineShape extends Shape {
  constructor(name = "LineShape") {
    super(name);
    this.__class = "LineShape";

    // Array of points {x,y}
    this.points = [];

    // Bounding box
    this.aabb = { minX: 0, minY: 0, maxX: 0, maxY: 0 };

    this.closed = false; // If true, will connect last -> first
  }

  // -----------------------
  // Geometry compute
  // -----------------------
  computeGeometry() {
    if (this.points.length === 0) return;

    let minX = this.points[0].x;
    let minY = this.points[0].y;
    let maxX = this.points[0].x;
    let maxY = this.points[0].y;

    for (const p of this.points) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    }

    this.aabb.minX = minX;
    this.aabb.minY = minY;
    this.aabb.maxX = maxX;
    this.aabb.maxY = maxY;
  }

  // -----------------------
  // Draw
  // -----------------------
  drawSelf(ctx) {
    if (this.points.length === 0) return;

    ctx.beginPath();
    ctx.moveTo(this.points[0].x, this.points[0].y);
    for (let i = 1; i < this.points.length; i++) {
      ctx.lineTo(this.points[i].x, this.points[i].y);
    }
    if (this.closed) ctx.closePath();

    if (this.fill.enabled) {
      ctx.fillStyle = this.fill.color;
      ctx.globalAlpha = this.fill.alpha;
      ctx.fill();
    }

    if (this.stroke.enabled) {
      ctx.strokeStyle = this.stroke.color;
      ctx.lineWidth = this.stroke.width;
      if (this.stroke.dash) ctx.setLineDash(this.stroke.dash);
      else ctx.setLineDash([]);
      ctx.globalAlpha = this.stroke.alpha;
      ctx.stroke();
    }
  }

  // -----------------------
  // Hit test
  // -----------------------
  hitTestLocal(x, y) {
    const tol = Math.max(2, this.stroke.width / 2);

    // Quick reject by AABB
    if (x < this.aabb.minX - tol || x > this.aabb.maxX + tol ||
      y < this.aabb.minY - tol || y > this.aabb.maxY + tol) return false;

    // Stroke test
    for (let i = 0; i < this.points.length - 1; i++) {
      const p0 = this.points[i];
      const p1 = this.points[i + 1];
      if (LineShape.distancePointToLine(x, y, p0.x, p0.y, p1.x, p1.y) <= tol) return true;
    }
    if (this.closed) {
      const p0 = this.points[this.points.length - 1];
      const p1 = this.points[0];
      if (LineShape.distancePointToLine(x, y, p0.x, p0.y, p1.x, p1.y) <= tol) return true;
    }

    // Fill test if closed
    if (this.fill.enabled && this.points.length > 2) {
      return LineShape.pointInPolygon({ x, y }, this.points);
    }

    return false;
  }

  // -----------------------
  // Dynamic point helpers
  // -----------------------
  addPoint(x, y) {
    this.points.push({ x, y });
    this.invalidateGeometry();
  }

  addPoints(...coordinates) {
    if (coordinates.length % 2 !== 0) {
      throw new Error('addPoints requires an even number of arguments (x,y pairs)');
    }

    for (let i = 0; i < coordinates.length; i += 2) {
      this.points.push({ x: coordinates[i], y: coordinates[i + 1] });
    }
    this.invalidateGeometry();
  }

  removePoint(index) {
    if (index >= 0 && index < this.points.length) {
      this.points.splice(index, 1);
      this.invalidateGeometry();
    }
  }

  // -----------------------
  // Utilities
  // -----------------------
  static distancePointToLine(px, py, x0, y0, x1, y1) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const len2 = dx * dx + dy * dy;
    if (len2 === 0) return Math.hypot(px - x0, py - y0);
    const t = ((px - x0) * dx + (py - y0) * dy) / len2;
    const tClamped = Math.max(0, Math.min(1, t));
    const closestX = x0 + tClamped * dx;
    const closestY = y0 + tClamped * dy;
    return Math.hypot(px - closestX, py - closestY);
  }

  static pointInPolygon(point, poly) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const xi = poly[i].x, yi = poly[i].y;
      const xj = poly[j].x, yj = poly[j].y;
      const intersect = ((yi > point.y) !== (yj > point.y)) &&
        (point.x < ((xj - xi) * (point.y - yi)) / (yj - yi + 0.0000001) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }

  // -----------------------
  // Serialization
  // -----------------------
  toJSON() {
    return {
      ...super.toJSON(),
      points: this.points,
      closed: this.closed,
      aabb: this.aabb
    };
  }

  static fromJSON(data) {
    const shape = super.fromJSON(data);
    shape.points = data.points ?? [];
    shape.closed = data.closed ?? false;
    shape.aabb = data.aabb ?? { minX: 0, minY: 0, maxX: 0, maxY: 0 };
    return shape;
  }

  afterLoad() {
    super.afterLoad();
    this.updateGeometry();
  }
}

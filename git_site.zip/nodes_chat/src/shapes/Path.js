

// src/shapes/Path.js
import { AABB } from "../core/AABB.js";

export class Path {
  constructor() {
    this.segments = [];
    this.closed = false;
    this.filled=!true; /// if true then hits area
    this.aabb = new AABB();
  }

  moveTo(x, y) {
    const p = { x, y };
    this.segments.push({ type: "moveTo", p });
    this.aabb.expandByPoint(x, y);
    return this;
  }

  lineTo(x, y) {
    const p = { x, y };
    this.segments.push({ type: "lineTo", p });
    this.aabb.expandByPoint(x, y);
    return this;
  }

  quadTo(cpX, cpY, x, y) {
    const cp = { x: cpX, y: cpY };
    const p = { x, y };
    this.segments.push({ type: "quadTo", cp, p });
    this.aabb.expandByPoint(cpX, cpY);
    this.aabb.expandByPoint(x, y);
    return this;
  }

  cubicTo(cp1X, cp1Y, cp2X, cp2Y, x, y) {
    const cp1 = { x: cp1X, y: cp1Y };
    const cp2 = { x: cp2X, y: cp2Y };
    const p = { x, y };
    this.segments.push({ type: "cubicTo", cp1, cp2, p });
    this.aabb.expandByPoint(cp1X, cp1Y);
    this.aabb.expandByPoint(cp2X, cp2Y);
    this.aabb.expandByPoint(x, y);
    return this;
  }

  closePath() {
    this.closed = true;
  }

  // --- hit test (your code unchanged) ---
  hitTestPoint(px, py, tolerance = 2) {
    let prev = null;
    const poly = [];
    let hitStroke = false;

    for (const seg of this.segments) {
      switch (seg.type) {
        case "moveTo":
          prev = seg.p;
          poly.push(seg.p);
          break;

        case "lineTo":
          if (prev &&
              Path.distancePointToLine(px, py, prev.x, prev.y, seg.p.x, seg.p.y) <= tolerance)
            return true;
          poly.push(seg.p);
          prev = seg.p;
          break;

        case "quadTo": {
          const pts = Path.subdivideQuad(prev, seg.cp, seg.p);
          for (let i = 0; i < pts.length - 1; i++) {
            if (Path.distancePointToLine(px, py, pts[i].x, pts[i].y, pts[i+1].x, pts[i+1].y) <= tolerance)
              return true;
          }
          poly.push(...pts.slice(1));
          prev = seg.p;
          break;
        }

        case "cubicTo": {
          const pts = Path.subdivideCubic(prev, seg.cp1, seg.cp2, seg.p);
          for (let i = 0; i < pts.length - 1; i++) {
            if (Path.distancePointToLine(px, py, pts[i].x, pts[i].y, pts[i+1].x, pts[i+1].y) <= tolerance)
              return true;
          }
          poly.push(...pts.slice(1));
          prev = seg.p;
          break;
        }
      }
    }

    if (this.filled && poly.length > 2)
      return Path.pointInPolygon({ x: px, y: py }, poly);

    return false;
  }

  // --- JSON ---
  toJSON() {
    return {
      closed: this.closed,
      filled:this.filled,
      segments: this.segments
    };
  }

  static fromJSON(data) {
    const p = new Path();
    p.closed = data.closed;
    p.filled=filled;
    p.segments = data.segments;
    for (const s of data.segments) {
      if (s.p) p.aabb.expandByPoint(s.p.x, s.p.y);
      if (s.cp) p.aabb.expandByPoint(s.cp.x, s.cp.y);
      if (s.cp1) p.aabb.expandByPoint(s.cp1.x, s.cp1.y);
      if (s.cp2) p.aabb.expandByPoint(s.cp2.x, s.cp2.y);
    }
    return p;
  }

  /* math helpers unchanged */
    // --------------------------
  // Utilities
  static distancePointToLine(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    if (dx === 0 && dy === 0) return Math.hypot(px - x1, py - y1);
    const t = Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)));
    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    return Math.hypot(px - projX, py - projY);
  }

  static pointInPolygon(point, polygon) {
    let x = point.x, y = point.y;
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i].x, yi = polygon[i].y;
      const xj = polygon[j].x, yj = polygon[j].y;
      const intersect = ((yi > y) !== (yj > y)) &&
        (x < (xj - xi) * (y - yi) / (yj - yi + 0.0000001) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }

  // approximate quadratic/cubic as polyline for hit-test
  static subdivideQuad(p0, cp, p1, steps = 20) {
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = (1 - t) ** 2 * p0.x + 2 * (1 - t) * t * cp.x + t ** 2 * p1.x;
      const y = (1 - t) ** 2 * p0.y + 2 * (1 - t) * t * cp.y + t ** 2 * p1.y;
      pts.push({ x, y });
    }
    return pts;
  }

  static subdivideCubic(p0, cp1, cp2, p1, steps = 20) {
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const mt = 1 - t;
      const x = mt ** 3 * p0.x +
                3 * mt ** 2 * t * cp1.x +
                3 * mt * t ** 2 * cp2.x +
                t ** 3 * p1.x;
      const y = mt ** 3 * p0.y +
                3 * mt ** 2 * t * cp1.y +
                3 * mt * t ** 2 * cp2.y +
                t ** 3 * p1.y;
      pts.push({ x, y });
    }
    return pts;
  }

  draw(ctx) {
    if (this.segments.length === 0) return;
    ctx.beginPath();
    for (const seg of this.segments) {
        switch (seg.type) {
            case "moveTo": ctx.moveTo(seg.p.x, seg.p.y); break;
            case "lineTo": ctx.lineTo(seg.p.x, seg.p.y); break;
            case "quadTo": ctx.quadraticCurveTo(seg.cp.x, seg.cp.y, seg.p.x, seg.p.y); break;
            case "cubicTo": ctx.bezierCurveTo(seg.cp1.x, seg.cp1.y, seg.cp2.x, seg.cp2.y, seg.p.x, seg.p.y); break;
        }
    }
    if (this.closed) ctx.closePath();
    ctx.fill();
    ctx.stroke();
}

}





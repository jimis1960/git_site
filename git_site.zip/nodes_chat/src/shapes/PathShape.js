// src/shapes/PathShape.js
import { Shape } from "./Shape.js";
import { Path } from "./Path.js";

export class PathShape extends Shape {
    constructor(name = "PathShape", path = new Path()) {
        super(name);
        this.__class = "PathShape";

        this.path = path;

        this.fill = true;
        this.stroke = true;
        this.strokeWidth = 2;
    }

  
    
 

hitTestLocal(x,y){

return this.path.hitTestPoint(x, y);
}


    

    drawSelf(ctx) {
       // ctx.save();
       // this.worldMatrix.setCanvasTransform(ctx);

        ctx.beginPath();
        for (const seg of this.path.segments) {
            switch (seg.type) {
                case "moveTo":
                    ctx.moveTo(seg.p.x, seg.p.y);
                    break;
                case "lineTo":
                    ctx.lineTo(seg.p.x, seg.p.y);
                    break;
                case "quadTo":
                    ctx.quadraticCurveTo(seg.cp.x, seg.cp.y, seg.p.x, seg.p.y);
                    break;
                case "cubicTo":
                    ctx.bezierCurveTo(
                        seg.cp1.x, seg.cp1.y,
                        seg.cp2.x, seg.cp2.y,
                        seg.p.x, seg.p.y
                    );
                    break;
            }
        }

        if (this.path.closed) ctx.closePath();

        if (this.fill) {
            ctx.fillStyle = this.hovered ? "#ffcc66" : "#88c";
            ctx.fill();
        }

        if (this.stroke) {
            ctx.strokeStyle = this.hovered ? "#ff0000" : "#000";
            ctx.lineWidth = this.strokeWidth;
            ctx.stroke();
        }

        // optional debug AABB
        if (this.hovered) {
            const a = this.path.aabb;
            ctx.strokeStyle = "rgba(109, 109, 131, 0.4)";
            ctx.strokeRect(a.minX, a.minY, a.width, a.height);
        }

     //   ctx.restore();
    }

    toJSON() {
        return {
            ...super.toJSON(),
            path: this.path.toJSON()
        };
    }

    static fromJSON(data) {
        const shape = new PathShape(data.name, Path.fromJSON(data.path));
        shape.fromJSONBase(data);
        return shape;
    }
}

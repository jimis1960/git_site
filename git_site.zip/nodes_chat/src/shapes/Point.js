// shapes/Point.js
import { Shape } from "./Shape.js";

export class Point extends Shape {
  constructor(x = 0, y = 0, size = 5, name = "Point") {
    super(name);
    this.position.x = x;
    this.position.y = y;
    this.size = size; // radius for hit detection / drawing
  }

  // -----------------------
  // Compute geometry (for AABB)
  // -----------------------
  computeGeometry() {
    const r = this.size / 2;
    this.aabb = {
      x0: this.position.x - r,
      y0: this.position.y - r,
      x1: this.position.x + r,
      y1: this.position.y + r
    };
  }

  // -----------------------
  // Draw the point
  // -----------------------
  drawSelf(ctx) {
    ctx.beginPath();
    ctx.arc(0, 0, this.size / 2, 0, Math.PI * 2);
    if (this.fill?.enabled) {
      ctx.fillStyle = this.fill.color;
      ctx.globalAlpha = this.fill.alpha;
      ctx.fill();
    }
    if (this.stroke?.enabled) {
      ctx.strokeStyle = this.stroke.color;
      ctx.lineWidth = this.stroke.width;
      ctx.stroke();
    }
  }

  // -----------------------
  // Hit test in local coordinates
  // -----------------------
  hitTestLocal(x, y) {
    const r = this.size / 2;
    return x * x + y * y <= r * r;
  }

  // -----------------------
  // Serialization
  // -----------------------
  toJSON() {
    return {
      ...super.toJSON(),
      size: this.size
    };
  }

  static fromJSON(data) {
    const pt = super.fromJSON(data); // restore base Shape props
    pt.size = data.size ?? 5;
    return pt;
  }

  afterLoad() {
    super.afterLoad();
    this.computeGeometry();
  }
}

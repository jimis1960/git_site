import { Shape } from "./Shape.js";

export class Poly extends Shape {
  constructor(name = "Poly") {
    super(name);
    this.__class = "Poly";

    this.points = [ {x:0,y:0}, {x:100,y:0} ]; // default 2-point line
    this.closed = false; // whether to connect last->first
    this.hovered = false;
  }

  // -----------------------
  // Build Path2D
  // -----------------------
  toPath2D() {
    const path = new Path2D();
    if (!this.points.length) return path;

    const [first, ...rest] = this.points;
    path.moveTo(first.x, first.y);
    for (const pt of rest) path.lineTo(pt.x, pt.y);
    if (this.closed && this.points.length > 2) path.closePath();

    return path;
  }

  // -----------------------
  // Draw itself
  // -----------------------
  drawSelf(ctx) {
    const path = this.toPath2D();

    if (this.fill?.enabled && this.closed) {
      ctx.fillStyle = this.fill.color;
      ctx.globalAlpha = this.fill.alpha ?? 1;
      ctx.fill(path);
    }

    if (this.stroke?.enabled) {
      ctx.strokeStyle = this.stroke.color;
      ctx.lineWidth = this.stroke.width ?? 1;
      ctx.setLineDash(this.stroke.dash ?? []);
      ctx.globalAlpha = this.stroke.alpha ?? 1;
      ctx.stroke(path);
    }
  }

  // -----------------------
  // Hit testing
  // -----------------------
  hitTestLocal(x, y) {
    
    const path = this.toPath2D();
    if (this.closed && this.fill?.enabled) {
      return ctx.isPointInPath(path, x, y) || ctx.isPointInStroke(path, x, y);
    }
    return ctx.isPointInStroke(path, x, y);
  }

  // -----------------------
  // Get a point along the poly
  // t in [0,1]
  // -----------------------
  getPoint(t) {
    if (this.points.length < 2) return null;

    // compute total length
    const lengths = [];
    let total = 0;
    for (let i=0;i<this.points.length-1;i++) {
      const dx = this.points[i+1].x - this.points[i].x;
      const dy = this.points[i+1].y - this.points[i].y;
      const len = Math.hypot(dx, dy);
      lengths.push(len);
      total += len;
    }

    const target = t * total;
    let acc = 0;
    for (let i=0;i<lengths.length;i++) {
      if (acc + lengths[i] >= target) {
        const l = target - acc;
        const ratio = l / lengths[i];
        const x = this.points[i].x + ratio * (this.points[i+1].x - this.points[i].x);
        const y = this.points[i].y + ratio * (this.points[i+1].y - this.points[i].y);
        return {x,y};
      }
      acc += lengths[i];
    }

    // fallback: last point
    return this.points[this.points.length-1];
  }

  // -----------------------
  // Get n points evenly along poly
  // -----------------------
  getPoints(n=10) {
    const pts = [];
    for (let i=0;i<n;i++) pts.push(this.getPoint(i/(n-1)));
    return pts;
  }

  // -----------------------
  // Serialization
  // -----------------------
  toJSON() {
    return {
      ...super.toJSON(),
      points: this.points.map(p=>({...p})),
      closed: this.closed
    };
  }

  afterLoad() {
    super.afterLoad();
    this.points = Array.isArray(this.points) ? this.points.map(p=>({...p})) : [];
    this.closed = !!this.closed;
  }
}

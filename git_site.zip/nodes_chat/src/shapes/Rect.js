// shapes/Rect.js
import { Shape } from "./Shape.js";

export class Rect extends Shape {
  constructor(x = 0, y = 0, width = 100, height = 100, name = "Rect") {
    super(name);
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }

  // -----------------------
  // Compute geometry (AABB)
  // -----------------------
  computeGeometry() {
    this.aabb = { x0: this.x, y0: this.y, x1: this.x + this.width, y1: this.y + this.height };
  }

  // -----------------------
  // Draw the rectangle
  // -----------------------
  drawSelf(ctx) {
    if (this.fill?.enabled) {
      ctx.fillStyle = this.fill.color;
      ctx.globalAlpha = this.fill.alpha ?? 1;
      ctx.fillRect(this.x, this.y, this.width, this.height);
    }

    if (this.stroke?.enabled) {
      ctx.strokeStyle = this.stroke.color;
      ctx.lineWidth = this.stroke.width;
      ctx.globalAlpha = this.stroke.alpha ?? 1;
      ctx.strokeRect(this.x, this.y, this.width, this.height);
    }
  }

  // -----------------------
  // Hit test in local coordinates
  // -----------------------
  hitTestLocal(px, py) {
    const insideFill =
      this.fill?.enabled &&
      px >= this.x &&
      px <= this.x + this.width &&
      py >= this.y &&
      py <= this.y + this.height;

    const halfStroke = (this.stroke?.width ?? 0) / 2;
    const hitStroke =
      this.stroke?.enabled &&
      px >= this.x - halfStroke &&
      px <= this.x + this.width + halfStroke &&
      py >= this.y - halfStroke &&
      py <= this.y + this.height + halfStroke &&
      !insideFill; // only stroke outside fill

    return insideFill || hitStroke;
  }

  // -----------------------
  // Serialization
  // -----------------------
  toJSON() {
    return {
      ...super.toJSON(),
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height
    };
  }

  static fromJSON(data) {
    const rect = super.fromJSON(data);
    rect.x = data.x ?? 0;
    rect.y = data.y ?? 0;
    rect.width = data.width ?? 100;
    rect.height = data.height ?? 100;
    return rect;
  }

  afterLoad() {
    super.afterLoad();
    this.computeGeometry();
  }
}

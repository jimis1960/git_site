import { Node } from "../core/Node.js"
import { Matrix3 } from "../core/Matrix3.js";
export class Shape extends Node {
  constructor(name = "Shape") {
    super(name);
    this.__class = "Shape";


    this.localMatrix = new Matrix3();
    this.worldMatrix = new Matrix3();
    this._invWorld = new Matrix3();
    this._invWorldDirty = true;

    this._invLocal = new Matrix3();
    this._invLocalDirty = true;

    this._worldDirty = true;
    this._geometryDirty = true;



    this.position = { x: 0, y: 0 };
    this.rotation = 0;
    this.scale = { x: 1, y: 1 };
    this.skew = { x: 0, y: 0 };

    this.stroke = { enabled: true, width: 1, color: "#65c923ff", alpha: 1, dash: null };
    this.fill = { enabled: true, color: "#fff", alpha: 1, gradient: null };
    this.hovered = false;

  }


  // -----------------------
  // Dirty propagation
  // -----------------------
  invalidateWorld() {
    this._worldDirty = true;
    for (const c of this.children) c.invalidateWorld();
  }

  invalidateGeometry() {
    this._geometryDirty = true;
    for (const c of this.children) c.invalidateGeometry();
  }
  /// gometry compute 
  computeGeometry() {
    // Base Shape does nothing
    // Subclasses override this to compute actual geometry
  }


  updateGeometry() {
    ////////////////  if (!this._geometryDirty) return;

    // Recompute this shape's geometry
    this.computeGeometry();  // implement in subclasses

    this._geometryDirty = false;

    // Propagate to children
    for (const child of this.children) {
      if (child.updateGeometry) {
        child.updateGeometry();
      }
    }
  }


  // -----------------------
  // Matrix updates
  // -----------------------
  updateLocalMatrix() {

    this.localMatrix.identity()
      .multiply(new Matrix3().makeTranslation(this.position.x, this.position.y))


      .multiply(new Matrix3().makeRotation(this.rotation))
      .multiply(new Matrix3().makeScale(this.scale.x, this.scale.y));
    this._invLocalDirty = true; // <--- new



  }

  updateWorldMatrix(parentMatrix = null) {
    if (!this._worldDirty) return;

    this.updateLocalMatrix();

    if (parentMatrix) {
      this.worldMatrix.copy(parentMatrix).multiply(this.localMatrix);
    } else {
      this.worldMatrix.copy(this.localMatrix);
    }

    this._worldDirty = false;
    this._invLocalDirty = true; // <--- new

    for (const child of this.children) {
      if (child.updateWorldMatrix) {
        child.updateWorldMatrix(this.worldMatrix);
      }
    }


  }

  getInverseWorldMatrix() {
    if (this._invWorldDirty) {
      this._invWorld.copy(this.worldMatrix).invert();
      this._invWorldDirty = false;
    }
    return this._invWorld;
  }

  getInverseLocalMatrix() {
    if (this._invLocalDirty) {
      this._invLocal.copy(this.localMatrix).invert();
      this._invLocalDirty = false;
    }
    return this._invLocal;
  }

  // -----------------------
  // Drawing
  // -----------------------
  draw(ctx) {

    ctx.save();

    this.updateWorldMatrix(); // ensure matrices are up-to-date
    this.localMatrix.applyCanvasTransform(ctx); /// ???



    this.drawSelf(ctx);

    for (const child of this.children) {
      if (child.draw) child.draw(ctx);
    }

    ctx.restore();
  }

  drawSelf(ctx) {
    // override in subclasses (LOCAL coords only)
  }

  // -----------------------
  // Hit testing
  // -----------------------
  hitTest(x, y) {
    const p = this.worldMatrix.clone().invert().applyToPoint(x, y);
    return this.hitTestLocal(p.x, p.y);
  }

  hitTestLocal(x, y) {
    return false;
  }

  // -----------------------
  // Transform setters
  // -----------------------
  setPosition(x, y) {
    this.position.x = x;
    this.position.y = y;
    this.invalidateWorld();
  }

  translate(dx, dy) {
    this.position.x += dx;
    this.position.y += dy;
    this.invalidateWorld();
  }

  setRotation(rad) {
    this.rotation = rad;
    this.invalidateWorld();
  }

  setScale(sx, sy) {
    this.scale.x = sx;
    this.scale.y = sy;
    this.invalidateWorld();
  }

  // -----------------------
  // Utilities
  // -----------------------
  canvasToLocal(x, y) {
    return this.worldMatrix.clone().invert().applyToPoint(x, y);
  }

  setCanvasTransform(ctx) {
    this.worldMatrix.setCanvasTransform(ctx);
  }

  toPath2D() {
    return null;
  }

  // -----------------------
  // Serialization
  // -----------------------
  toJSON() {
    return {
      ...super.toJSON(),
      __class: this.__class,
      position: this.position,
      rotation: this.rotation,
      scale: this.scale,
      stroke: this.stroke,
      fill: this.fill,
      hovered: this.hovered
    };
  }

  static fromJSON(data) {
    const shape = super.fromJSON(data); // Node.fromJSON()

    // Restore Shape-specific properties
    shape.position = data.position ?? { x: 0, y: 0 };
    shape.rotation = data.rotation ?? 0;
    shape.scale = data.scale ?? { x: 1, y: 1 };
    shape.stroke = data.stroke ?? { enabled: true, width: 1, color: "#65c923ff", alpha: 1, dash: null };
    shape.fill = data.fill ?? { enabled: true, color: "#fff", alpha: 1, gradient: null };
    shape.hovered = data.hovered ?? false;

    return shape;
  }

  afterLoad() {
    super.afterLoad();      // restore parent/child links
    this.updateWorldMatrix();   // recompute world transforms
    this.updateGeometry();      // recompute geometry
  }
}
